/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  This source code is licensed under the Apache License, Version 2.0; found in the
 *  LICENSE file in the root directory of this source tree.
 * @file login event
 */
const LoginUI = require('../../src/components/login');
const code = require('../../src/webview/util/constant').code;
let loginUI;
// 调用登录完成后返回的状态码
const RES_TYPE = {
    SUCESS: {
        status: '0',
        message: '登录成功',
        data: {
            code
        }
    },
    NET_ERROR: {
        status: '99999',
        message: 'network error'
    },
    NOT_LOGIN: {
        status: '10004',
        message: 'user not login'
    },
    REQUEST_TIMEOUT: {
        status: '10007',
        message: 'request_timeout 清检查网络状况和超时设置'
    },
    APP_KEY_ERR: {
        status: '-1',
        message: '请登录开发者工具，并检查是否正确配置appid(project.swan.json)'
    }
};
async function login(context) {
    // timeout 超时设置 超时针对的是获取授权code的网络请求超时
    if (!loginUI) {
        loginUI = new LoginUI();
        // 监听用户点击关闭登录事件,并发送事件
        loginUI.on('platform-login-close', () => {
            context.event.send('platform-login-close');
        });
    }
    else {
        // 调起登录窗口
        loginUI.show();
    }
    loginUI.attach(context.el);
    return new Promise(resolve => {
        // 监听登录成功事件,返回相应的状态码到登录入口
        context.event.on('platform-login-success', () => {
            loginUI.hide();
            resolve(RES_TYPE.SUCESS);
        });
        // 监听发送的关闭登录窗口事件,返回相应的状态码到登录入口
        context.event.on('platform-login-close', () => {
            resolve(RES_TYPE.NOT_LOGIN);
        });
        // 监听登录失败事件,返回相应的状态码到登录入口
        context.event.on('platform-login-fail', () => {
            resolve(RES_TYPE.NOT_LOGIN);
        });
        // 刷新 topbar刷新按钮
        context.event.once('refresh', () => {
            resolve(RES_TYPE.NOT_LOGIN);
        });
    });
}

module.exports = {
    login
};