/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  This source code is licensed under the Apache License, Version 2.0; found in the
 *  LICENSE file in the root directory of this source tree.
 * @file authorize event
 */
// 获取已经授权scope,当前授权状态,以及返回结果
let {authorizeList, tempStatus, RES_TYPE} = require('../../src/webview/util/constant');
// scope为要获得的授权功能
function authorizeAsync(context, scope) {
    // 从context获取项目信息
    const {app: {serverInfo: appInfor}} = context;
    let scopeDetail = tempStatus[scope].name;
    // 判断是否处于授权状态,若已经授权,返回相应的状态码到授权入口
    if (tempStatus[scope].permit) {
        return Promise.resolve(RES_TYPE.SUCESS);
    } else {
        // 若要获得的授权信息在授权列表里, 调起调起授权窗口
        if (authorizeList.indexOf(scope) >= 0) {
            // 发送事件,调起showModal
            return context.event.send('show-modal', {
                    data: {
                        eventUID: 'swanApi.authorize',
                        title: '模拟百度APP授权',
                        titleSize: '18px',
                        showCancel: true,
                        cancelText: '拒绝',
                        cancelColor: '#000000',
                        confirmText: '允许',
                        confirmColor: '#3C76FF',
                        authorizeInfo: {
                            icon: appInfor.app_photo,
                            name: appInfor.app_name,
                            detail: scopeDetail + '仅供参考'
                        }
                    }
                }).then(res => {
                    // 用户点击取消授权按钮
                    if (res.data.cancel) {
                        return Promise.resolve(RES_TYPE.USER_DENY);
                    }
                    // 用户点击允许授权
                    if (res.data.confirm) {
                        tempStatus[scope].permit = true;
                        return Promise.resolve(RES_TYPE.SUCESS);
                    }
                });
        } else {
            // 若要获得的授权信息不在授权列表里, 返回相应的状态码到授权入口
            return Promise.resolve(RES_TYPE.NOT_FOUND);
        }
    }
}
// todo 授权清理
async function clearAuthorize(context) {
    const {network: {request}, app: {serverInfo: appInfor}, event} = context;
    const appKey = appInfor.app_key;
    let bduss = (await event.send('get-simulator-bduss-stoken')).data.bduss;
    authorizeList = null;
}

module.exports = {
    authorizeAsync,
    clearAuthorize
};