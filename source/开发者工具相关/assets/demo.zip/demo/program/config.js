/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  This source code is licensed under the Apache License, Version 2.0; found in the
 *  LICENSE file in the root directory of this source tree.
 *
 * @file demo宿主的配置
 */



/**
 * 获取宿主 extensionJs 版本区间
 *
 * @param {Object=} versions 版本信息
 * @param {string} versions.swanJsVersion 当前 swanJs 版本号
 * @param {string} versions.swanNativeVersion 当前 swanNative 版本号
 * @param {string} versions.extensionJsVersion 当前 extensionJs 版本号
 * @return {string} extensionJs semver表达式，用于更新和选择的筛选
 */
exports.getExtensionJsRange = (versions) => {
    return '^1.0.0';
};


/**
 * 获取宿主app版本号
 *
 * @param {Object=} versions 版本信息
 * @param {string} versions.swanJsVersion 当前 swanJs 版本号
 * @param {string} versions.swanNativeVersion 当前 swanNative 版本号
 * @param {string} versions.extensionJsVersion 当前 extensionJs 版本号
 * @return {string} hostAppVersion 宿主app版本号
 */
exports.getHostAppVersion = (versions) => {
    return '13.0.0';
};

/**
 * 获取宿主 app useragent 的后缀
 *
 * @param {Object} versions 同上
 * @return {string} suffix useragent 后缀
 */
exports.getUserAgentSuffix = (versions) => {
    return 'suffix'
};
