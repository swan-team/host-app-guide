/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  This source code is licensed under the Apache License, Version 2.0; found in the
 *  LICENSE file in the root directory of this source tree.
 *
 * @file 授权-常量
 */
// 已经授权scope
let authorizeList = [
    'mobile',
    'snsapi_userinfo',
    'mapp_location',
    'mapp_images',
    'mapp_camera',
    'mapp_record',
    'mapp_choose_invoice',
    'mapp_choose_address'
];
// 控制当前登录状态变量
let loginToken = false;
// 授权状态
let tempStatus = {
    'mobile': {
        name: '模拟绑定的手机号码',
        permit: false
    },
    'snsapi_userinfo': {
        name: '模拟获取你的公开信息（昵称、头像等）',
        permit: false
    },
    'mapp_location': {
        name: '模拟获取你的地理位置',
        permit: false
    },
    'mapp_images': {
        name: '模拟使用你的系统相册',
        permit: false
    },
    'mapp_camera': {
        name: '模拟使用你的系统相机',
        permit: false
    },
    'mapp_record': {
        name: '模拟使用你的系统录音',
        permit: false
    },
    'mapp_choose_invoice': {
        name: '模拟使用你的发票信息',
        permit: false
    },
    'mapp_choose_address': {
        name: '模拟使用你的地址信息',
        permit: false
    }
};
// 对应授权返回参数
let RES_TYPE = {
    SUCESS: {
        status: '0',
        message: '授权成功'
    },
    NET_ERROR: {
        status: '99999',
        message: 'network error'
    },
    DEFAULT_ERR: {
        status: '10001',
        message: 'internal_error'
    },
    USER_DENY: {
        status: '10003',
        message: 'user deny'
    },
    NOT_LOGIN: {
        status: '10004',
        message: 'user not login'
    },
    SYSTEM_DENY: {
        status: '10005',
        message: 'system deny'
    },
    NOT_FOUND: {
        status: '10006',
        message: 'not found'
    },
    APP_KEY_ERR: {
        status: '-1',
        message: '请登录开发者工具，并检查是否正确配置appid(project.swan.json)'
    }
};
// 登录调用成功,返回测试Authorization Code, 仅供参考。
let code = '7a7sd81020ee2345rr566t6z090';

module.exports = {
    authorizeList,
    loginToken,
    tempStatus,
    RES_TYPE,
    code
};