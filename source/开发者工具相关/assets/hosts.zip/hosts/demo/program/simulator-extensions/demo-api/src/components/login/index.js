/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  This source code is licensed under the Apache License, Version 2.0; found in the
 *  LICENSE file in the root directory of this source tree.
 *
 * @file 登录端能力
 *
 */

const Component = require('san').Component;
const join = require('path').join;


const passportUrl = 'https://smartapp.baidu.com/static/miniappdoc/html/swanIDE/login/login.html';

class Login extends Component {
    initData() {
        return {
            isShow: true,
            passportUrl,
            preloadPath: join(__dirname, 'preload.js'),
            refreshText: '刷新',
            title: '登录',
            anchor: this.getAnchor.bind(this),
            constraints: [{to: 'window', attachment: 'together', pin: true}]
        };
    }

    show(target) {
        this.data.set('isShow', true);
        this.refresh();
        this.data.set('target', target);
    }

    hide() {
        this.data.set('isShow', false);
    }

    closeLogin() {
        this.hide();
        this.fire('platform-login-close');
    }

    refresh({event} = {}) {
        this.ref('wv') && this.ref('wv').refresh();
        event && event.stopPropagation();
    }

    getAnchor() {
        return this.data.get('target');
    }
}

Login.template = /* html*/`
    <div>
        <div s-if="isShow" class="test-login-container">
            <div class="mask" on-click="closeLogin">
                <div class="test-login">
                    <div class="test-login-title">百度app扫码登录模拟器
                    <p class="test-login-title-point">(模拟登陆,仅供参考)</p>
                    </div>
                    <ui-webview
                        class="login-webview"
                        s-ref="wv"
                        src="{{passportUrl}}"
                        name="simulator"
                        preload="{{preloadPath}}"/>
                    <div class="login-refresh-text" on-click="refresh({event: $event})">{{refreshText}}</div>
                </div>
            </div>
        </div>
    </div>
`;
module.exports = Login;
