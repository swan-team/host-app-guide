/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  This source code is licensed under the Apache License, Version 2.0; found in the
 *  LICENSE file in the root directory of this source tree.
 *
 * @file 重写登录扫码登录之后的回调
 */

module.exports = context => {
    // 扫码登录成功后，调用的函数
    window.sendRenderSuc = () => {
        context.event.send('platform-login-success');
    };

    // 扫码登录失败后，调用的函数
    window.sendRenderLoginFail = () => {
        context.event.send('platform-login-fail');
    };
};
