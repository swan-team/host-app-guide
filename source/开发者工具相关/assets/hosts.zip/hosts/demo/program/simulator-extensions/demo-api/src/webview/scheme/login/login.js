/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  模拟登录,设置loginToken为当前登录状态,当调用swan.login的时候,判断loginToken的值,
 *  若为true则为登录状态,若为false则调起登录窗口,扫码登录。
 *
 * @file login
 */
// 获取登录状态
let loginToken = require('../../util/constant').loginToken;
exports.login = context => async ({query: {callback, params}}) => {
    const cb = params.cb;
    // 超时设置 超时针对的是获取授权code的网络请求超时
    const timeout = +params.timeout || 0;
    const execute = context.utils.execute;
    execute(callback, {
        status: 0,
        message: 'success'
    });
    // 如果loginToken为true,为登录状态,返回成功
    if (loginToken) {
        execute(cb, {status: '0', message: '登录成功'});
    } else {
        // 发送platform-login事件,调起登录功能
        context.event.send('platform-login', {
            timeout
        }).then(res => {
            if (res.status === '0') {
                loginToken = true;
            };
            // 监听并发送最后返回的处理结果
            execute(cb, res);
        });
    }
};
