/**
 * @license
 *  Copyright Baidu Inc. All Rights Reserved.
 *
 *  模拟授权,设置tempStatus为当前授权状态,当调用swan.authorize的时候,根据需要获取权限的scope,判断当前是否授权,
 *  若当前处于授权状态,返回成功,若为false调起授权窗口由用户确定是否允许授权。
 *
 * @file authorize
 */
const authorizeAsync = require('../../../event/authorize').authorizeAsync;

exports.authorize = context => async ({query: {callback, params}}) => {
    const cb = params.cb;
    const execute = context.utils.execute;
    execute(callback, {
        status: 0,
        message: 'success'
    });
    // 要获得授权的功能
    let scope = params.scope;
    // 判断授权状态的逻辑实现
    authorizeAsync(context, scope).then(
    res => {
        execute(cb, res);
    });
};
